[![ko-fi](https://img.shields.io/badge/Ko--fi-Donate%20-hotpink?logo=kofi&logoColor=white&style=for-the-badge)](https://ko-fi.com/protocol1903) [![](https://img.shields.io/badge/Discord-Community-blue?style=for-the-badge)](https://discord.gg/K3fXMGVc4z)

Adds the cargo bays and unloaders from space age, without the need for space age to be enabled. Recipes balanced for vanilla, recipes for other mods available upon request.

Compatibility:
- [PyMods](https://mods.factorio.com/mod/pyalternativeenergy)

My mods are made 100% by humans, with no computer generated code or graphics.
If you have a mod idea, let me know and I can look into it.