if not mods.pyalternativeenergy then return end

require "__pypostprocessing__.lib"

TECHNOLOGY("landing-pad-unloading-bay"):replace_prereq("space-science-pack", "rocket-silo"):remove_pack("space-science-pack"):remove_pack("utility-science-pack"):remove_pack("production-science-pack"):add_pack("py-science-pack-3")
RECIPE("cargo-bay"):set_ingredient_amount("steel-plate", 60):set_ingredient_amount("low-density-structure", 30):replace_ingredient("processing-unit", {type = "item", name = "advanced-circuit", amount = 10}):add_ingredient{type = "item", name = "titanium-plate", amount = 20}
RECIPE("landing-pad-unloading-bay"):set_ingredient_amount("steel-chest", 15):set_ingredient_amount("electric-engine-unit", 40):replace_ingredient("processing-unit", {type = "item", name = "advanced-circuit", amount = 25}):add_ingredient{type = "item", name = "mechanical-parts-02", amount = 2}
