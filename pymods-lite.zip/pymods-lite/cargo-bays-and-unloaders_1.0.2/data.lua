local item_sounds = require("__base__.prototypes.item_sounds")
local procession_graphic_catalogue_types = require("__base__/prototypes/planet/procession-graphic-catalogue-types")

local cargo_bay_hatch_opening_sound = {
  sound = {
    filename = "__cargo-bays-and-unloaders__/sounds/cargo-bay-hatch-opening-loop.ogg",
    volume = 0.6,
    modifiers = volume_multiplier("main-menu", 2.5),
    aggregation = {max_count = 1, remove = true, count_already_playing = true}
  },
  stopped_sound = {
    filename = "__cargo-bays-and-unloaders__/sounds/cargo-bay-hatch-opening-stop.ogg",
    volume = 0.35,
    modifiers = volume_multiplier("main-menu", 2.5),
    aggregation = {max_count = 1, remove = true, count_already_playing = true}
  },
  minimal_sound_duration_for_stopped_sound = 25,
}
local cargo_bay_hatch_closing_sound = {
  sound = {
    filename = "__cargo-bays-and-unloaders__/sounds/cargo-bay-hatch-closing-loop.ogg",
    volume = 0.6,
    modifiers = volume_multiplier("main-menu", 2.5),
    aggregation = {max_count = 1, remove = true, count_already_playing = true}
  },
  stopped_sound = {
    filename = "__cargo-bays-and-unloaders__/sounds/cargo-bay-hatch-closing-stop.ogg",
    volume = 0.35,
    modifiers = volume_multiplier("main-menu", 2.5),
    aggregation = {max_count = 1, remove = true, count_already_playing = true}
  }
}

local function hub_pod_shadow_offset()
  return {2, 2.5}
end

local function placeholder_shared_bay_hatch_animation()
  return
  {
    layers =
    {
      util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/hatches/shared-bay-hatch",
        {
          priority = "high",
          frame_count = 21,
          animation_speed = 0.5,
          scale = 0.5,
          shift = util.by_pixel(11, 16),
          run_mode = "forward-then-backward"
        }),
      util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/hatches/shared-bay-hatch-shadow",
        {
          priority = "high",
          frame_count = 21,
          scale = 0.5,
          shift = util.by_pixel(11, 16),
          run_mode = "forward-then-backward",
          draw_as_shadow = true,
        }),
        util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/hatches/shared-bay-hatch-emission",
        {
          priority = "high",
          frame_count = 3,
          scale = 0.5,
          shift = util.by_pixel(11, 16),
          run_mode = "forward-then-backward",
          draw_as_glow = true,
          blend_mode = "additive",
          frame_sequence = {1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,3,3}
        }),
    }
  }
end

shared_bay_hatch = shared_bay_hatch or function (hatch_offset, hatch_illumination_index)
  return
  {
    hatch_graphics = placeholder_shared_bay_hatch_animation(),
    offset = hatch_offset,
    slice_height = 0.5,
    sky_slice_height = -0.5,
    travel_height = 3,
    pod_shadow_offset = hub_pod_shadow_offset();
    illumination_graphic_index = hatch_illumination_index,
    cargo_unit_entity_to_spawn = "cargo-pod",
    receiving_cargo_units = {"cargo-pod"},
    opening_sound = cargo_bay_hatch_opening_sound,
    closing_sound = cargo_bay_hatch_closing_sound,
  }
end

data:extend{
  {
    type = "cargo-bay",
    name = "cargo-bay",
    flags = {"placeable-player", "player-creation"},
    icon = "__cargo-bays-and-unloaders__/graphics/icon/cargo-bay.png",
    corpse = "cargo-bay-remnants",
    dying_explosion = "electric-furnace-explosion",
    collision_box = {{-1.9, -1.9}, {1.9, 1.9}},
    selection_box = {{-2, -2}, {2, 2}},
    max_health = 1000,
    minable = {mining_time = 1, result = "cargo-bay"},
    inventory_size_bonus = 20,
    hatch_definitions =
    {
      shared_bay_hatch({-0.32, -1.5}, procession_graphic_catalogue_types.hatch_emission_bay)
    },
    graphics_set =
    {
      water_reflection =
      {
        pictures =
        {
          filename = "__cargo-bays-and-unloaders__/graphics/entity/bays/planet-bay-reflections.png",
          priority = "extra-high",
          width = 32,
          height = 32,
          shift = util.by_pixel(0, 100),
          variation_count = 1,
          scale = 4
        },
        rotate = false,
        orientation_to_variation = false
      },
      connections = require("__base__.graphics.entity.cargo-hubs.connections.planet-connections"),
      picture =
      {
        {
          render_layer = "lower-object-above-shadow",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-0",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
          }
        },
        {
          render_layer = "object",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/planet-cargo-bay-3",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-shadow",
            {
              scale = 0.5,
              shift = {3, 0.5},
              draw_as_shadow = true
            }),
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-emission",
            {
              scale = 0.5,
              shift = {0, -1},
              draw_as_glow = true,
              blend_mode = "additive"
            })
          }
        },
        {
          render_layer = "cargo-hatch",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/hatches/planet-cargo-bay-occluder",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
          }
        }
      }
    },
    platform_graphics_set =
    {
      connections = require("__cargo-bays-and-unloaders__.graphics.entity.connections.platform-connections"),
      picture =
      {
        {
          render_layer = "lower-object-above-shadow",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-0",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
          }
        },
        {
          render_layer = "object",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/platform-cargo-bay-3",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-shadow",
            {
              scale = 0.5,
              shift = {3, 0.5},
              draw_as_shadow = true
            }),
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/shared-cargo-bay-emission",
            {
              scale = 0.5,
              shift = {0, -1},
              draw_as_glow = true,
              blend_mode = "additive"
            })
          }
        },
        {
          render_layer = "cargo-hatch",
          layers =
          {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/hatches/platform-cargo-bay-occluder",
            {
              scale = 0.5,
              shift = {0, -1}
            }),
          }
        }
      }
    }
  },
  {
    type = "cargo-bay",
    name = "landing-pad-unloading-bay",
    flags = {"placeable-player", "player-creation"},
    icon = "__cargo-bays-and-unloaders__/graphics/icon/cargo-unloading-bay.png",
    corpse = "cargo-bay-remnants",
    dying_explosion = "electric-furnace-explosion",
    collision_box = {{-1.9, -2.9}, {1.9, 1.9}},
    selection_box = {{-2, -3}, {2, 2}},
    connectable_box = {{-1.9, -1.9}, {1.9, 1.9}},
    tile_width = 4,
    tile_height = 4,
    max_health = 1000,
    minable = {mining_time = 1, result = "landing-pad-unloading-bay"},
    inventory_size_bonus = 20,
    allow_unloading = true,
    has_direction = true,
    use_unloading_distance_limit = true,
    surface_conditions =
    {
      {
        property = "gravity",
        min = 1
      }
    },
    graphics_set =
    {
      water_reflection =
      {
        pictures =
        {
          filename = "__cargo-bays-and-unloaders__/graphics/entity/bays/planet-bay-reflections.png",
          priority = "extra-high",
          width = 32,
          height = 32,
          shift = util.by_pixel(0, 100),
          variation_count = 1,
          scale = 4
        },
        rotate = false,
        orientation_to_variation = false
      },
      connections = require("__base__.graphics.entity.cargo-hubs.connections.planet-connections"),
      picture =
      {
        north =
        {
          {
            render_layer = "lower-object-above-shadow",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-n-1",{scale=0.5})
            }
          },
          {
            render_layer = "object",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-n-4",{scale=0.5}),
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-n-shadow",{scale = 0.5, shift = util.by_pixel(32, 0), draw_as_shadow = true})
            }
          }
        },
        east =
        {
          {
            render_layer = "object-under",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-e-3",{scale=0.5})
            }
          },
          {
            render_layer = "object",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-e-4",{scale=0.5}),
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-e-shadow",{scale = 0.5, shift = util.by_pixel(32, 0), draw_as_shadow = true})
            }
          }
        },
        south =
        {
          {
            render_layer = "object-under",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-s-3",{scale=0.5})
            }
          },
          {
            render_layer = "object",
            layers =
            {
            util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-s-shadow",{scale = 0.5, shift = util.by_pixel(32, 0), draw_as_shadow = true})
            },
          },
          {
            render_layer = "cargo-hatch", -- boosted to draw above S walls
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-s-4",{scale=0.5})
            }
          }
        },
        west =
        {
          {
            render_layer = "object-under",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-w-3",{scale=0.5})
            }
          },
          {
            render_layer = "object",
            layers =
            {
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-w-4",{scale=0.5}),
              util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/extractor/extractor-w-shadow",{scale = 0.5, shift = util.by_pixel(32, 0), draw_as_shadow = true})
            }
          }
        }
      }
    }
  },
  {
    type = "corpse",
    name = "cargo-bay-remnants",
    icon = "__cargo-bays-and-unloaders__/graphics/icon/cargo-bay.png",
    flags = {"placeable-neutral", "not-on-map"},
    hidden_in_factoriopedia = true,
    subgroup = "defensive-structure-remnants",
    order = "a-l-a",
    selection_box = {{-2, -2}, {2, 2}},
    collision_box = {{-1.9, -1.9}, {1.9, 1.9}},
    tile_width = 4,
    tile_height = 4,
    selectable_in_game = false,
    time_before_removed = 60 * 60 * 15, -- 15 minutes
    expires = false,
    final_render_layer = "remnants",
    remove_on_tile_placement = false,
    animation = make_rotated_animation_variations_from_sheet (4, util.sprite_load("__cargo-bays-and-unloaders__/graphics/entity/bays/planet-bay-remnants",
        {
          direction_count = 1,
          scale = 0.5
        }))
  },
  {
    type = "item",
    name = "cargo-bay",
    icon = "__cargo-bays-and-unloaders__/graphics/icon/cargo-bay.png",
    icon_size = 64,
    subgroup = "space-related",
    order = "c[cargo-bay]",
    inventory_move_sound = item_sounds.mechanical_large_inventory_move,
    pick_sound = item_sounds.mechanical_large_inventory_pickup,
    drop_sound = item_sounds.mechanical_large_inventory_move,
    place_result = "cargo-bay",
    space_platform_request_priority = true,
    stack_size = 10,
    weight = 100 * kg
  },
  {
    type = "item",
    name = "landing-pad-unloading-bay",
    icon = "__cargo-bays-and-unloaders__/graphics/icon/cargo-unloading-bay.png",
    icon_size = 64,
    subgroup = "space-related",
    order = "c[landing-pad-unloading-bay]",
    inventory_move_sound = item_sounds.mechanical_large_inventory_move,
    pick_sound = item_sounds.mechanical_large_inventory_pickup,
    drop_sound = item_sounds.mechanical_large_inventory_move,
    place_result = "landing-pad-unloading-bay",
    stack_size = 10,
    weight = 200 * kg
  },
  {
    type = "recipe",
    name = "cargo-bay",
    enabled = false,
    ingredients =
    {
      {type = "item", name = "steel-plate", amount = 20},
      {type = "item", name = "low-density-structure", amount = 20},
      {type = "item", name = "processing-unit", amount = 5}
    },
    energy_required = 10,
    results = {{type="item", name="cargo-bay", amount=1}}
  },
  {
    type = "recipe",
    name = "landing-pad-unloading-bay",
    enabled = false,
    ingredients =
    {
      {type = "item", name = "cargo-bay", amount = 1},
      {type = "item", name = "steel-chest", amount = 4},
      {type = "item", name = "electric-engine-unit", amount = 15},
      {type = "item", name = "processing-unit", amount = 8}
    },
    energy_required = 10,
    results = {{type="item", name="landing-pad-unloading-bay", amount=1}}
  },
  {
    type = "technology",
    name = "landing-pad-unloading-bay",
    icon = "__cargo-bays-and-unloaders__/graphics/technology/cargo-unloading-bay.png",
    icon_size = 256,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "landing-pad-unloading-bay"
      },
      {
        type = "max-cargo-bay-unloading-distance",
        modifier = 59
      }
    },
    prerequisites = {"space-science-pack"},
    unit =
    {
      count = 2500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 60
    }
  },
}

-- add cargo bays to vanilla space silo tech
local tech = data.raw.technology["rocket-silo"]
tech.effects = tech.effects or {}
tech.effects[#tech.effects+1] = {
  type = "unlock-recipe",
  recipe = "cargo-bay"
}

-- adjust base cargo landing pad
table.insert(data.raw["cargo-landing-pad"]["cargo-landing-pad"].flags, "hide-alt-info")
data.raw["cargo-landing-pad"]["cargo-landing-pad"].trash_inventory_size = 20
data.raw["cargo-landing-pad"]["cargo-landing-pad"].cargo_station_parameters.hatch_definitions =
{
  planet_upper_hatch({0.5, -3.5},  2.25, 3, -0.5, procession_graphic_catalogue_types.planet_hatch_emission_in_1),
  planet_upper_hatch({2, -3.5},    2.25, 3, -0.5, procession_graphic_catalogue_types.planet_hatch_emission_in_2),
  planet_upper_hatch({1.25, -2.5}, 1.25, 3, -1  , procession_graphic_catalogue_types.planet_hatch_emission_in_3)
}
data.raw["cargo-landing-pad"]["cargo-landing-pad"].cargo_station_parameters.giga_hatch_definitions =
{
  planet_upper_giga_hatch({0,1,2})
}

-- add empty-space if needed
if not data.raw.tile["empty-space"] then
  local tile_pollution = require("__base__/prototypes/tile/tile-pollution-values")
  data:extend{
    {
      name = "empty-space",
      type = "tile",
      order = "z[other]-b[empty-space]",
      subgroup = "special-tiles",
      collision_mask =
      {
        layers=
        {
          ground_tile=true,
          water_tile=true,
          empty_space=true,
          resource=true,
          floor=true,
          item=true,
          object=true,
          player=true,
          doodad=true
        },
      },
      layer_group = "zero",
      layer = 0,
      effect_color = {0.5, 0.507, 0},
      effect_color_secondary = { 0, 68, 25 },
      particle_tints =
      {
        primary = {0, 0, 0, 0},
        secondary = {0, 0, 0, 0},
      },
      variants =
      {
        main =
        {
          {
            picture = "__cargo-bays-and-unloaders__/graphics/terrain/empty-space.png",
            count = 1,
            size = 1
          }
        },
        empty_transitions = true
      },
      map_color = {0, 0, 0},
      absorptions_per_second = tile_pollution.out_of_map,
      autoplace = {probability_expression = 1},
    },
  }
end

require "compatibility.pyalternativeenergy"