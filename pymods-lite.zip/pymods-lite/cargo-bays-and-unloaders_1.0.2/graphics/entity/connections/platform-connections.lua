return require("__base__/graphics/entity/cargo-hubs/connections/connections")("__cargo-bays-and-unloaders__/graphics/entity/connections/platform-", 118)
