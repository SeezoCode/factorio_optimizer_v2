return
{
  width = 300,
  height = 296,
  shift = util.by_pixel( 27.0, 1.0),
  line_length = 1,
}
