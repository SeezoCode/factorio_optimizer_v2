return
{
  width = 300,
  height = 318,
  shift = util.by_pixel( 26.0, -15.5),
  line_length = 1,
}
