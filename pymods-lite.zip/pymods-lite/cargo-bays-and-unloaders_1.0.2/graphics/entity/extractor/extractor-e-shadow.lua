return
{
  width = 376,
  height = 278,
  shift = util.by_pixel( 17.0, -4.5),
  line_length = 1,
}
