return
{
  width = 256,
  height = 242,
  shift = util.by_pixel( -2.0, -50.0),
  line_length = 1,
}
