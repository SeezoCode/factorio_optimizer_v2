return
{
  width = 226,
  height = 242,
  shift = util.by_pixel( -1.5, -42.5),
  line_length = 1,
}
