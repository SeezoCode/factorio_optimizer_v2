return
{
  width = 358,
  height = 304,
  shift = util.by_pixel( -1.5, -27.0),
  line_length = 1,
}
