return
{
  width = 252,
  height = 360,
  shift = util.by_pixel( 0.5, 14.5),
  line_length = 1,
}
