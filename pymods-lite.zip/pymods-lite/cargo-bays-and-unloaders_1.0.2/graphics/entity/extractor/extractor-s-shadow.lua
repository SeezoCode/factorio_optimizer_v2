return
{
  width = 372,
  height = 352,
  shift = util.by_pixel( 1.5, 11.0),
  line_length = 1,
}
