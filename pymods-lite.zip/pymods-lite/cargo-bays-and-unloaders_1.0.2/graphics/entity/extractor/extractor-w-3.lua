return
{
  width = 316,
  height = 286,
  shift = util.by_pixel( -31.5, -3.0),
  line_length = 1,
}
