return
{
  width = 292,
  height = 328,
  shift = util.by_pixel( -21.5, -17.0),
  line_length = 1,
}
