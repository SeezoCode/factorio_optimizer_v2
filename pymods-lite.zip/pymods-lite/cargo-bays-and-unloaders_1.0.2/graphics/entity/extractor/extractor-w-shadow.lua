return
{
  width = 432,
  height = 284,
  shift = util.by_pixel( -19.5, -5.0),
  line_length = 1,
}
