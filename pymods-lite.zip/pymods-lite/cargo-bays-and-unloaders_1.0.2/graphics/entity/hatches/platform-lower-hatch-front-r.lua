return
{
  width = 176,
  height = 124,
  shift = util.by_pixel( -39.5, 46.5),
  line_length = 6,
}
