return
{
  width = 172,
  height = 110,
  shift = util.by_pixel( -54.0, 63.5),
  line_length = 6,
}
